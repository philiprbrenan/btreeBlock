[build-menu]
FT_00_LB=_Compile
FT_00_CM=perl -I/home/phil/perl/cpan/MakeWithPerl/lib -M"MakeWithPerl" -e"MakeWithPerl::makeWithPerl" -- --compile "%d/%f" --javaHome "%d"
FT_00_WD=
FT_01_LB=Execute
FT_01_CM=perl -I/home/phil/perl/cpan/MakeWithPerl/lib -M"MakeWithPerl" -e"MakeWithPerl::makeWithPerl" -- --run "%d/%f" --javaHome "%d"
FT_01_WD=
